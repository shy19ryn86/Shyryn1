package com.dmc.auth.dto;

public record UserResponse(
        Long id,
        String email,
        String username,
        String role,
        boolean enabled,
        String careerTrack
) {
}
