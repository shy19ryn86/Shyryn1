import os
import sys
import logging
from datetime import datetime, timezone
from contextlib import asynccontextmanager

bootstrap_logger = logging.getLogger(__name__)

try:
    import matplotlib
    matplotlib.use('Agg')
except Exception as exc:
    bootstrap_logger.warning('Matplotlib setup failed, continuing without explicit backend setup: %s', exc)
    matplotlib = None

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

_app_dir = os.path.dirname(__file__)
_repo_root = os.path.dirname(_app_dir)
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)

load_dotenv(os.path.join(_repo_root, '.env'))
load_dotenv(os.path.join(_app_dir, '.env'), override=True)

from api.v1 import FEATURE_NAMES, ROUTERS

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
logger = logging.getLogger(__name__)
INTERNAL_API_KEY = os.environ.get('DMC_INTERNAL_API_KEY', '')


def _is_non_dev_environment() -> bool:
    env = (os.environ.get('DMC_ENV') or os.environ.get('ENV') or os.environ.get('FASTAPI_ENV') or 'dev').strip().lower()
    return env in {'prod', 'production', 'staging', 'stage', 'preprod'}


def _validate_internal_key_or_fail() -> None:
    if _is_non_dev_environment() and (not INTERNAL_API_KEY or INTERNAL_API_KEY.strip() == '' or INTERNAL_API_KEY == 'change-me'):
        raise RuntimeError(
            'Unsafe configuration: DMC_INTERNAL_API_KEY must be set to a non-default value in non-dev environments'
        )


def _error_envelope(request: Request, status_code: int, code: str, message: str, details=None):
    safe_details = jsonable_encoder(
        details,
        custom_encoder={
            Exception: lambda e: str(e),
            ValueError: lambda e: str(e),
        },
    )
    return {
        'error': {
            'code': code,
            'message': message,
            'status': status_code,
            'path': request.url.path,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'details': safe_details,
        }
    }


@asynccontextmanager
async def lifespan(app: FastAPI):
    _validate_internal_key_or_fail()
    api_key = os.environ.get('GOOGLE_AI_API_KEY', '')
    if api_key:
        logger.info('GOOGLE_AI_API_KEY is set: %s...%s', api_key[:4], api_key[-4:])
    else:
        logger.warning('GOOGLE_AI_API_KEY is not set — chatbot will not work')
    yield


app = FastAPI(
    title='DMC Math Engine',
    description='Discrete Math Calculator — вычислительный микросервис',
    version='2.0.0',
    lifespan=lifespan,
    redoc_url=None,  # отключаем ReDoc, используем только /docs (Swagger UI)
)

_cors_origins_raw = os.environ.get('DMC_CORS_ORIGINS', 'http://localhost:8080,http://localhost:3000')
_cors_origins = [o.strip() for o in _cors_origins_raw.split(',') if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.middleware('http')
async def add_api_version_header(request: Request, call_next):
    if request.url.path.startswith('/api/v1/') and request.url.path != '/api/v1/status':
        # Only validate API key if it's configured and not the default value
        if INTERNAL_API_KEY and INTERNAL_API_KEY != 'change-me':
            inbound_key = request.headers.get('X-Internal-Api-Key', '')
            if inbound_key != INTERNAL_API_KEY:
                payload = _error_envelope(request, 401, 'INTERNAL_API_KEY_INVALID', 'Invalid internal API key')
                return JSONResponse(status_code=401, content=payload)

    response = await call_next(request)
    response.headers['X-API-Version'] = 'v1'
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    message = exc.detail if isinstance(exc.detail, str) else 'Request failed'
    payload = _error_envelope(request, exc.status_code, 'HTTP_ERROR', message, details=exc.detail)
    return JSONResponse(status_code=exc.status_code, content=payload)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    payload = _error_envelope(
        request,
        422,
        'VALIDATION_ERROR',
        'Validation failed',
        details=exc.errors(),
    )
    return JSONResponse(status_code=422, content=payload)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception('Unhandled exception on %s: %s', request.url.path, exc)
    payload = _error_envelope(request, 500, 'INTERNAL_ERROR', 'Internal server error')
    return JSONResponse(status_code=500, content=payload)

for router in ROUTERS:
    app.include_router(router)


@app.get('/api/v1/status', tags=['Health'])
def status():
    return {
        'status': 'online',
        'version': '2.0.0',
        'features': FEATURE_NAMES,
    }


if __name__ == '__main__':
    import uvicorn
    uvicorn.run('app:app', host='0.0.0.0', port=8081, reload=True)
