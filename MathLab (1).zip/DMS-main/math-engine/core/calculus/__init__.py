"""Calculus core (SymPy)."""
