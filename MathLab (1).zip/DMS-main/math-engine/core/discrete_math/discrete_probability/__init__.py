"""Discrete probability domain package."""
